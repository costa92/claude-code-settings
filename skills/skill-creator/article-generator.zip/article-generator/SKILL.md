---
name: article-generator
description: Generate, optimize, and batch-create WeChat Official Account articles with brand consistency and industry best practices. Use when writing complete articles from scratch, rewriting/optimizing existing drafts, batch-generating multiple articles, or adapting content for WeChat platform. Supports mixed input sources (topics, documents, web search) and outputs Markdown format with proper structure, SEO optimization, and engagement elements. Includes AI image generation prompts and stock image recommendations for cover images and article illustrations.
---

# Article Generator

## Overview

Generate high-quality WeChat Official Account articles that follow platform best practices, maintain brand consistency, and engage target audiences. Support complete article creation, content optimization, and batch generation workflows.

## Core Capabilities

### 1. Complete Article Creation

Create full articles from scratch based on topic or keywords, including:
- Engaging headline design (15-30 characters, keyword-optimized)
- Structured body content with proper pacing and visual breaks
- Opening hook that resonates with reader pain points
- Clear value proposition and content preview
- Segmented main content with subheadings, examples, and data
- Actionable conclusion with call-to-action

**Input sources:**
- Topic/keywords only
- Existing documents or drafts
- Web research results
- Mixed sources

### 2. Content Optimization & Rewriting

Improve existing articles by:
- Refining headline impact and SEO optimization
- Restructuring content for better mobile readability
- Enhancing paragraph density (3-5 lines per paragraph)
- Adding visual elements (emoji, bold text, quotes, lists)
- Strengthening opening hooks and closing CTAs
- Improving language flow and engagement

### 3. Batch Article Generation

Generate multiple articles efficiently:
- Process topic lists in batch mode
- Maintain consistent brand voice across articles
- Apply unified style guidelines
- Optimize for different article lengths (short/medium/long)

### 4. Image Generation & Curation

Create or recommend images for articles:
- **Direct image generation** using Google Gemini API (via nanobanana MCP tool)
- **Cover image design** (900x383px, 2.35:1 ratio)
- **Section illustrations** (rhythm images every 300-500 words)
- **Data visualizations** (charts, infographics, diagrams)
- **Fallback AI prompts** for Midjourney/Stable Diffusion/文心一格
- **Stock image recommendations** with proper sourcing
- **Image optimization** (sizing, compression, mobile-friendly)

**Primary method**: Use `nanobanana` MCP tool to generate images directly with Gemini API
**Fallback method**: Provide detailed AI prompts if image generation fails

## Workflow Decision Tree

```
Start: What type of task?
│
├─ New Article Creation
│  ├─ Gather Requirements
│  │  ├─ Topic/keywords
│  │  ├─ Target audience
│  │  ├─ Article length preference
│  │  ├─ Industry/category
│  │  └─ Image generation needs
│  ├─ Apply Style Guidelines
│  │  ├─ Check brand_style_template.md if provided
│  │  └─ Use writing_guidelines.md defaults
│  ├─ Research & Structure
│  │  ├─ Conduct web search if needed
│  │  ├─ Review reference materials
│  │  └─ Plan content outline
│  ├─ Generate & Format
│  │  ├─ Write headline (15-30 chars)
│  │  ├─ Create structured body
│  │  ├─ Add visual elements
│  │  └─ Output as Markdown
│  └─ Image Planning & Generation
│     ├─ Identify image positions (cover + rhythm images)
│     ├─ Determine image types (illustration/photo/chart)
│     ├─ Generate images using nanobanana (Gemini API)
│     ├─ Save images to local directory
│     ├─ Fallback: provide AI prompts if generation fails
│     ├─ Specify image specs (size, style, format)
│     └─ Include image references in output
│
├─ Content Optimization
│  ├─ Read existing content
│  ├─ Identify improvement areas
│  │  ├─ Headline effectiveness
│  │  ├─ Paragraph density
│  │  ├─ Visual hierarchy
│  │  ├─ Engagement elements
│  │  └─ Image placement & quality
│  ├─ Apply optimization techniques
│  ├─ Suggest image improvements
│  └─ Output refined version
│
└─ Batch Generation
   ├─ Parse topic list
   ├─ For each topic:
   │  ├─ Follow "New Article Creation" workflow
   │  └─ Apply consistent style
   └─ Output multiple articles
```

## Writing Guidelines

Follow platform-specific best practices defined in `references/writing_guidelines.md`:

**Article Structure:**
- **Opening (first 3 paragraphs):** Pain point resonance → Value promise → Content preview
- **Main Body:** Segmented with subheadings, examples, data, and visual breaks
- **Conclusion:** Summary (1-3 key points) → CTA (engage/share) → Extended reading

**Language Style:**
- Use first-person ("我", "我们") to build connection
- Conversational tone, avoid overly formal language
- One idea per sentence, avoid nested clauses
- Specific over abstract, use concrete examples
- Active verbs for stronger narrative

**Formatting Standards:**
- Emoji before subheadings (optional, based on brand style)
- Blank lines between paragraphs and sections
- Use `>` for important quotes or highlights
- Lists for 3+ parallel items
- Bold for key points, avoid over-highlighting

**SEO Optimization:**
- Core keyword in headline
- Keyword appears in first 100 characters
- Natural keyword integration in subheadings
- Keyword density 2-3%
- Optimal length: 1500-3000 characters
- Reading time: 3-8 minutes

**Image Integration:**
- Follow standards in `references/image_guidelines.md`
- **Use nanobanana MCP tool** to generate images with Gemini API
- Cover image: 900x383px (2.35:1 ratio) - use aspect ratio 47:20
- Rhythm images: every 300-500 words - use aspect ratio 3:2 or 1:1
- Style consistency across all images
- Proper image compression (<500KB per image)
- Alt text and attribution when needed
- Save generated images to `images/` directory with descriptive names

## Brand Customization

### Using Brand Style Guide

If the user has a specific brand voice or guidelines:

1. **Request or create** `references/brand_style_template.md` with:
   - Brand positioning and target audience
   - Language style and tone preferences
   - Prohibited words and preferred terminology
   - Visual formatting rules (emoji, spacing, emphasis)
   - Content themes and topics to avoid
   - Citation and sourcing standards

2. **Apply brand guidelines** throughout article generation:
   - Reference the brand style guide when making language choices
   - Maintain consistency across multiple articles
   - Adapt templates to match brand personality

3. **Template customization:**
   - Use `assets/article_template.md` as baseline structure
   - Modify according to brand-specific requirements
   - Adjust emoji usage, heading styles, and CTA formats

### Industry-Specific Adaptations

**Technology:**
- Explain technical terms with analogies
- Include data visualizations and charts
- Focus on trends and industry dynamics

**Finance:**
- Include risk disclaimers
- Cite data sources explicitly
- Avoid absolute statements

**Education:**
- Provide actionable methodologies
- Include examples and exercises
- Consider audience age/education level

**Lifestyle:**
- Emphasize practicality and actionability
- Rich imagery and scenario-based content
- Light, engaging language

## Output Format

Generate all articles in **Markdown format** with:

```markdown
# [Article Headline]

> Lead: 1-2 sentence summary

---

## 📌 Opening Section

[Content...]

---

## 💡 Main Point 1

[Content with examples, data, lists...]

---

## 🎯 Conclusion

**Key Takeaways:**
1. [Point 1]
2. [Point 2]
3. [Point 3]

---

## 🤝 Call to Action

[Engagement question or sharing request]
```

**Markdown advantages:**
- Easy to edit and version control
- Clean conversion to HTML
- Platform-agnostic format
- Supports all necessary formatting (bold, lists, quotes, headings)

## Resources

### references/

**writing_guidelines.md** - Comprehensive WeChat Official Account writing standards:
- Article structure templates
- Language and style guidelines
- Industry-specific adaptations
- SEO optimization techniques

Load this file when:
- Creating new articles from scratch
- User asks for "best practices" or "optimization"
- Need guidance on headline, structure, or formatting

**brand_style_template.md** - Customizable brand voice template:
- Brand information and positioning
- Language tone and prohibited terms
- Visual formatting preferences
- Content themes and sourcing standards

Load this file when:
- User mentions brand-specific requirements
- Creating multiple articles with consistent voice
- User provides their own brand guidelines to fill in

**image_guidelines.md** - Complete image strategy for WeChat articles:
- Image types and use cases (cover, rhythm, functional, emotional)
- Design principles (style unity, quality control, content relevance)
- AI image generation workflow with prompt templates
- Tool recommendations (Canva, Midjourney, stock libraries)
- Industry-specific image styles
- Image optimization and compliance checklist

Load this file when:
- User requests images or "配图"
- Generating articles that need visual enhancement
- User asks about cover image design
- Need to create AI image generation prompts
- Optimizing existing article images

**gemini_image_generation.md** - Gemini API image generation guide (via nanobanana):
- nanobanana MCP tool usage and parameters
- Aspect ratio selection for different image types
- Prompt writing techniques and templates
- Batch generation workflow
- Common scenarios and prompt examples
- Error handling and fallback strategies

Load this file when:
- Need to generate images directly using Gemini
- User requests "生成配图" or "生成图片"
- Batch generating images for articles
- Need prompt examples for specific scenarios

### assets/

**article_template.md** - Markdown structure template:
- Complete article skeleton with all sections
- Placeholder guidance for each component
- Emoji and formatting examples
- Adaptable for different article types

Use this template:
- As starting point for new articles
- To ensure structural consistency
- When user requests "standard format"
- For batch generation baseline

## Usage Examples

**Example 1: Complete Article Creation**
```
User: "写一篇关于时间管理的公众号文章"

Process:
1. Clarify: target audience, article length, specific angle
2. Load: references/writing_guidelines.md
3. Research: time management techniques if needed
4. Generate: headline + structured content + CTA
5. Format: Markdown with proper visual elements
6. Output: Complete article ready for publication
```

**Example 1b: Article with Image Generation**
```
User: "写一篇关于时间管理的公众号文章，帮我生成配图"

Process:
1. Clarify: target audience, article length, image style preference
2. Load: references/writing_guidelines.md + gemini_image_generation.md
3. Generate: complete article content
4. Plan images:
   - Cover image (16:9, later crop to 900x383px)
   - 3-4 rhythm images for sections (3:2 or 1:1)
5. Use nanobanana to generate images:
   - Cover: "时间管理主题，清晨阳光办公桌，手绘插画风格，温暖色调"
   - Pic1: "四象限矩阵图表，扁平插画风格，蓝橙配色，简洁专业"
   - Pic2: "职场人士高效工作场景，温暖色调，现代办公室"
6. Save images to ./images/ directory
7. Output: Article + embedded image references + generation summary
```

**Example 2: Content Optimization**
```
User: "优化这篇文章" [provides existing draft]

Process:
1. Read: existing content
2. Analyze: headline impact, structure, paragraph density, engagement
3. Load: references/writing_guidelines.md for standards
4. Refine: headline, opening, body structure, visual elements, conclusion
5. Output: Optimized version with change notes
```

**Example 3: Batch Generation with Brand Voice**
```
User: "根据我们的品牌风格,批量生成5篇职场效率相关文章"

Process:
1. Request: brand style guide (or use template)
2. Receive: topic list or generate topic angles
3. Load: references/brand_style_template.md
4. For each article:
   - Apply brand voice consistently
   - Use writing_guidelines.md structure
   - Maintain unified formatting
5. Output: 5 articles with consistent brand tone
```

**Example 4: Industry-Specific Article**
```
User: "写一篇金融理财类的公众号文章,主题是基金定投"

Process:
1. Note: finance industry requirements (disclaimers, sourcing)
2. Load: references/writing_guidelines.md (finance section)
3. Research: recent fund investment data if needed
4. Generate: with required risk disclaimers and data citations
5. Format: include proper sourcing for all statistics
6. Output: Compliant finance article
```

**Example 5: Image-Only Request**
```
User: "帮我为这篇文章设计封面图和配图方案"

Process:
1. Read: existing article content
2. Load: references/gemini_image_generation.md
3. Analyze: article theme, tone, key sections
4. Design cover:
   - Identify article core message
   - Determine visual style (based on brand/industry)
   - Write Gemini-optimized prompt
5. Plan rhythm images:
   - Mark image positions (every 300-500 words)
   - Match image type to content (illustration/photo/chart)
   - Write prompts for each position
6. Use nanobanana to generate all images:
   - Cover (16:9): [detailed prompt]
   - Pic1 (3:2): [detailed prompt]
   - Pic2 (3:2): [detailed prompt]
   - ...
7. Save images to ./images/ directory
8. Output:
   - Generated image file paths
   - Image embedding markdown
   - Style guide for consistency
```

## Best Practices

1. **Clarify before creating:** Always understand target audience, desired length, image needs, and any brand requirements before generating content

2. **Mobile-first mindset:** Keep paragraphs short (3-5 lines), use visual breaks, optimize for thumb-scrolling

3. **Engagement optimization:** Include hooks in opening, actionable content in body, clear CTA in conclusion

4. **Consistency in batch:** When generating multiple articles, maintain unified voice, structure, formatting, and image style

5. **Reference wisely:** Load writing_guidelines.md for standards, brand_style_template.md for voice, article_template.md for structure, image_guidelines.md for visuals

6. **Iterate with user:** For brand-specific work, generate sample then refine based on feedback to align with expectations

7. **SEO conscious:** Naturally integrate keywords, optimize headline, maintain proper length and structure

8. **Platform compliance:** Follow WeChat platform content policies, include necessary disclaimers for sensitive industries

9. **Image integration:** When images are requested, use nanobanana MCP tool to generate images directly with Gemini API. Plan placement strategically (cover + rhythm images), maintain style consistency. If generation fails, provide fallback AI prompts or stock recommendations

10. **Image optimization:** Always specify image dimensions and aspect ratios (cover: 16:9 → crop to 900x383px, rhythm: 3:2 or 1:1), compression targets (<500KB), and ensure mobile-friendly display

11. **Gemini image generation:** Load gemini_image_generation.md for prompt templates, use nanobanana tool with appropriate aspect ratios, save images to ./images/ directory with descriptive names
